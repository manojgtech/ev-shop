 <!-- Preloader -->
<!--
        <div class="preloader">
            <div class="loader">
                <div class="shadow"></div>
                <div class="box"></div>
            </div>
        </div>
-->
        <!-- End Preloader -->


<!--
<div id="page"></div>
<div id="loading"></div>
-->



<!--
<div id="page">
    <h1>Cooking in progress..</h1>
</div>
-->

<!--
<div id="cooking">
<img src="../assets/img/loader.gif" alt="" title="">
</div>-->
