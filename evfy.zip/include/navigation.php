<!-- Start Header Area -->
<header class="header-area p-relative navbar-style-three mainheader">

<div class="top-header top-header-style-three">
<div class="container-fluid2">
<div class="row align-items-center">
<div class="col-lg-8 col-md-8">
<ul class="top-header-contact-info">
<li>
Call: 
<a href="tel:#">+91-93111 11437</a>
</li>
</ul>

<div class="top-header-social">
<span>Follow us:</span>
<a href="https://twitter.com/evfyin" class="d-block" target="_blank"><i class='fa fa-twitter'></i></a>
<a href="https://www.instagram.com/evfy.in/" class="d-block" target="_blank"><i class='fa fa-instagram'></i></a>
<a href="https://api.whatsapp.com/send?phone=919311111437&text=&source=&data=&app_absent=" class="d-block" target="_blank"><i class='fa fa-whatsapp'></i></a>

</div>
</div>

<div class="col-lg-4 col-md-4">
<ul class="top-header-login-register">
<li><a href="login.php"><i class='fa fa-user'></i></a></li>
<li><a href="#"><i class='fa fa-language'></i></a></li>
<li><a href="#"><i class='fa fa-map-marker'></i></a></li>
<li><a href="#" data-toggle="modal" data-target="#exampleModal"><i class='fa fa-sun-o'></i></a></li>
</ul>
</div>
</div>
</div>
</div>

<!-- Start Navbar Area -->
<nav class="navbar navbar-expand-lg navbar-light bg-light rounded maintopnavigation mainnav">
<a class="navbar-brand" href="./">
<img src="assets/img/EVFY-logo.png">
</a>
<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbars" aria-expanded="false" aria-label="Toggle navigation">
<span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbar">
<ul class="navbar-nav ml-auto">



<!--
<li class="nav-item dropdown megamenu-li">
<a class="nav-link dropdown-toggle" href="index.php" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Home</a>
</li>
-->

<!--
<li class="nav-item dropdown megamenu-li">
<a class="nav-link dropdown-toggle" href="" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Two Wheelers <i class='fa fa-caret-down'></i></a>
<ul class="dropdown-menu">
<li class="nav-item"><a href="blog-style-1.html" class="nav-link">High Speed Scooters</a></li>
<li class="nav-item"><a href="blog-style-2.html" class="nav-link">Low Speed Scooters</a></li>
</ul>
</li>
-->

<li class="nav-item dropdown megamenu-li">
<a class="nav-link" href="" id="dropdown02" aria-haspopup="true" aria-expanded="false">Personal Mobility</a>
</li>
    

<li class="nav-item dropdown megamenu-li">
<a class="nav-link dropdown-toggle" href="" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">e-Cycles <i class='fa fa-caret-down'></i></a>
<ul class="dropdown-menu">
<li class="nav-item"><a href="e-cycle.php" class="nav-link">Kinetic Kool E-Cycle</a></li>
</ul>
</li>

<!--
<li class="nav-item dropdown megamenu-li">
<a class="nav-link dropdown-toggle" href="" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">e-Cycles</a>
</li>
-->

<!--
<li class="nav-item dropdown megamenu-li">
<a class="nav-link dropdown-toggle" href="" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Two Wheelers</a>
</li>
-->
    
<li class="nav-item dropdown megamenu-li">
<a class="nav-link" href="kinetic-two-wheelers.php" >Two Wheelers <i class='fa fa-caret-down'></i></a>
<ul class="dropdown-menu">
<li class="nav-item"><a href="kinetic-zoom.php" class="nav-link">Kinetic Zoom</a></li>
<li class="nav-item"><a href="kinetic-zing.php" class="nav-link">Kinetic Zing</a></li>
</ul>
</li>

<li class="nav-item dropdown megamenu-li">
<a class="nav-link dropdown-toggle" href="" id="dropdown02" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Four Wheelers</a>
</li>

    

    
    
<!--
<li class="nav-item dropdown megamenu-li">
<a class="nav-link dropdown-toggle" href="" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Personal Mobility <i class='fa fa-caret-down'></i></a>
<ul class="dropdown-menu">
<li class="nav-item"><a href="#" class="nav-link">e-Cycles</a></li>
<li class="nav-item"><a href="#" class="nav-link">Two Wheelers</a></li>
<li class="nav-item"><a href="#" class="nav-link">Four Wheelers</a></li>
<li class="nav-item"><a href="#" class="nav-link">Charging Location</a></li>
</ul>
</li>
-->


<li class="nav-item dropdown megamenu-li">
<a class="nav-link" href="charging-location.php" aria-haspopup="true" aria-expanded="false">Charging Locations</a>
</li>
    
    <li class="nav-item dropdown megamenu-li">
<a class="nav-link" href="" aria-haspopup="true" aria-expanded="false">Blog</a>
</li>

 

<!--
<li class="nav-item dropdown megamenu-li">
<a class="nav-link" href="#">EV News & Reviews</a>
</li>
-->
<!--

<li class="nav-item dropdown megamenu-li">
<a class="nav-link" href="#">Accessories</a>
</li>
-->

<!--
<li class="nav-item dropdown megamenu-li">
<a class="nav-link" href="#">Contact Us</a>
</li>
-->

<!--
<li class="nav-item dropdown megamenu-li">
<a class="nav-link" href="#">More...</a>
    <ul class="dropdown-menu">
<li class="nav-item"><a href="#" class="nav-link">Feedback</a></li>
<li class="nav-item"><a href="#" class="nav-link">Faq's</a></li>
<li class="nav-item"><a href="#" class="nav-link">EV Insurance</a></li>
<li class="nav-item"><a href="#" class="nav-link">EMI Calculator</a></li>
</ul>
</li>
-->




</ul>

<div class="others-option">
<div class="search-box d-inline-block">
<i class='fa fa-search'></i>
</div>
</div>
</div>
</nav>
<!-- End Navbar Area -->




<!-- Start Sticky Navbar Area -->

<!-- End Sticky Navbar Area -->




</header>
<!-- End Header Area -->