var ids=[];
var baseurl="http://localhost:8081/evfy/";
function chechThisc(id,pid){
    console.log(id,pid);
    if($("#"+pid).is(":checked")){
        if(!ids.includes(id)){
        ids.push(id);
        }
    }else{
        if(ids.includes(id)){
            var i=ids.indexOf(id);
             if (i > -1) {
                ids.splice(i, 1); 
            }
        }
    }
    
    
}

function checkAll(id){
    if($("#"+id).is(":checked")){
        $("thead input").attr("checked","checked");
        $("tfoot input").attr("checked","checked");
        var trs=$("tbody tr");
       
        if(ids.length<trs.length){
            trs.each(function(index){
                 console.log(this);
            ids.push($(this).attr("data-id"));
            $(this).find(".pids").attr("checked","checked");
            });
        }
   }else{
       $("thead input").removeAttr("checked");
        $("tfoot input").removeAttr("checked");
        $(".pids").removeAttr("checked");
       ids=[];
   }
    
}

function showEditForm(id){
    $("#cat-form").html('');
     $.ajax({
     type: "POST",
     url: baseurl+'vendor/catModel.php',
     data: {id:id,func:'editC'},
     success: function(response){
         console.log(response);
         $("#cat-form-edit").html(response);
         $("#editcatspopup").modal();
     }
});
    
}

function showEditbrandForm(id){
    $("#brand-form").html('');
     $.ajax({
     type: "POST",
     url: baseurl+'vendor/brandModel.php',
     data: {id:id,func:'editC'},
     success: function(response){
         console.log(response);
         $("#brand-form-edit").html(response);
         $("#editbrandspopup").modal();
     }
});
    
}
function showDelAlert(id){
    $("#delpopup_btn").attr("data-id",id);
    $("#deletecatspopup").modal();
}

function showDelBrandAlert(id){
    $("#delpopup_btn").attr("data-id",id);
    $("#deletebrandpopup").modal();
}

// $(document).ready(function(){
//     loadCategory();
//     loadProduct();
//     loadBrands();
// });

function loadCategory(){
    $("#bloader").show();
                    $.ajax({
                type: "POST",
                url: baseurl+'vendor/catModel.php',
                data: {func:'viewC'},
                success: function(response){
                    
                    $("#catdiv").html(response);
                     $('#catdataTable').DataTable();
                     $("#bloader").hide();
                }
            });
    }
    function loadBrands(){
    $("#bloader").show();
                    $.ajax({
                type: "POST",
                url: baseurl+'vendor/brandModel.php',
                data: {func:'viewC'},
                success: function(response){
                    
                    $("#branddiv").html(response);
                     $('#catdataTable').DataTable();
                     $("#bloader").hide();
                }
            });
    }
    //load products
    function loadProduct(){
    $("#bloader").show();
                    $.ajax({
                type: "POST",
                url: baseurl+'vendor/productModel.php',
                data: {func:'viewProd'},
                success: function(response){
                    
                    $("#prodsdiv").html(response);
                     $('#prodsdataTable').DataTable();
                     $("#bloader").hide();
                }
            });
    }

    function editCat(th){
        let formdata=$("#cat-form-edit").serialize();
        //var data = new FormData(formdata
        $.ajax({
                type: "POST",
                url: baseurl+'vendor/catModel.php',
                data: {func:'updateC',data:formdata},
                success: function(response){
                    if(response==1){
                        setTimeout(() => {
                            $("#editcatspopup").modal('hide');
                            loadCategory();
                        }, 5000);
                        
                    }
                    
                }
            });
    }

    function editBrand(th){
        let formdata=$("#brand-form-edit").serialize();
        //var data = new FormData(formdata
        $.ajax({
                type: "POST",
                url: baseurl+'vendor/brandModel.php',
                data: {func:'updateC',data:formdata},
                success: function(response){
                    if(response==1){
                        setTimeout(() => {
                            $("#editbrandpopup").modal('hide');
                            loadBrand();
                        }, 5000);
                        
                    }
                    
                }
            });
    }
    function addcat(th){
        let formdata=$("#cat-form-add").serialize();
        var ds=formdata.split('&');
        var names=ds[0].split('=');
        var name=names[1];
        
        if(name=='' || name.length==0){
            $("#addcatModel .modal-body form").append("<p>Category name is required</p>");
            return false;
        }
        $.ajax({
                type: "POST",
                url: baseurl+'vendor/catModel.php',
                data: {func:'addC',data:formdata},
                success: function(response){
                    if(response==1){
                        setTimeout(() => {
                            $("#addcatModel").modal('hide');
                            loadCategory();
                        }, 5000);
                }
            }
            });
    }

    //add brand

    function addBrand(th){
        let formdata=$("#brand-form-add").serialize();
        var ds=formdata.split('&');
        var names=ds[0].split('=');
        var name=names[1];
        
        if(name=='' || name.length==0){
            $("#addcatModel .modal-body form").append("<p>brand name is required</p>");
            return false;
        }
        $.ajax({
                type: "POST",
                url: baseurl+'vendor/brandModel.php',
                data: {func:'addC',data:formdata},
                success: function(response){
                    if(response==1){
                        setTimeout(() => {
                            $("#addbrandModel").modal('hide');
                            loadBrand();
                        }, 5000);
                }
            }
            });
    }

    function delcat(){
        $("#deletecatspopup").modal("hide");
        var id=$("#delpopup_btn").attr("data-id"); 
        $.ajax({
                type: "POST",
                url: baseurl+'vendor/catModel.php',
                data: {func:'delC',data:id},
                success: function(response){
                    if(response==1){
                        setTimeout(() => {
                            
                            loadCategory();
                        }, 2000);
                        
                    }
                }
            });

    }

    function delbrand(){
        $("#deletebrandpopup").modal("hide");
        var id=$("#delpopup_btn").attr("data-id"); 
        $.ajax({
                type: "POST",
                url: baseurl+'vendor/brandModel.php',
                data: {func:'delC',data:id},
                success: function(response){
                    if(response==1){
                        setTimeout(() => {
                            
                            loadBrand();
                        }, 2000);
                        
                    }
                }
            });

    }


 $('#file').fileinput({
        theme: 'fas',
        
        uploadUrl: '#',
        allowedFileExtensions: ['jpg', 'png', 'gif']
    });


    //show brands

    function showprodbrand(id){
        var cat=$("#"+id).val();

        $.ajax({
                type: "POST",
                url: baseurl+'vendor/brandModel.php',
                data: {func:'showcatbrand',data:cat},
                success: function(response){
                    if(response!='0'){
                        var resp=JSON.parse(response);
                        var html="";
                        resp.forEach(row => {
                           console.log(row);
                            html+=`<option value=${row.id}>${row.brand_name}</option>`;
                        });
                        $("#product_ibrands").html(html);
                    }else{
                        html=`<option value='0'>No brand</option>`;
                        $("#product_ibrands").html(html);
                    }
                        
                    }
                });


    }
    //toggle visible specs

function toggleSpecs(val){
    console.log(val);
    if(val=='yes'){
        $("#specsDiv").show();
    }else{
         $("#specsDiv").hide();
    }
}

//open lightbox

function prevImg(path){
    $("#image-gallery-image").attr("src",path);
    $("#image-gallery").modal('show');

}