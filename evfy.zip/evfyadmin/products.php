<?php require_once("header.php"); ?>
<?php
$results1 = DB::query("SELECT * FROM products WHERE status=1");


?>
<style>
  .btn:focus,
  .btn:active,
  button:focus,
  button:active {
    outline: none !important;
    box-shadow: none !important;
  }

  #image-gallery .modal-footer {
    display: block;
  }

  .thumb {
    margin-top: 15px;
    margin-bottom: 15px;
  }
</style>
<!-- Begin Page Content -->
<div class="container-fluid">

  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Products</h6>
      <a href="addProduct.php"><i class="fa fa-plus float-right"></i></a>
    </div>
    <div class="card-body">
      <div class="spinner-border  loaddiv" id="bloader" style="display:none;"></div>
      <div class="table-responsive" id="prodsdiv">

      </div>
    </div>
  </div>

</div>
</div>
<!-- End of Main Content -->
<div class="modal fade" tabindex="-1" role="dialog" id="editcatspopup">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Category</h4>
        <button type="button" class="close" style="float:right;" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form id="cat-form">

        </form>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="modal fade" tabindex="-1" role="dialog" id="deletecatspopup">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Delete Category</h4>
        <button type="button" class="close" style="float:right;" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <p>Do you want to delete it?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" id="delpopup_btn" data-id="" onclick="delcat();">Save changes</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!-- Footer -->
<div class="modal fade" id="image-gallery" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="image-gallery-title"></h4>
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span>
        </button>
      </div>
      <div class="modal-body">
        <img id="image-gallery-image" class="img-responsive col-md-12" src="">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary float-left" id="show-previous-image"><i class="fa fa-arrow-left"></i>
        </button>

        <button type="button" id="show-next-image" class="btn btn-secondary float-right"><i class="fa fa-arrow-right"></i>
        </button>
      </div>
    </div>
  </div>
</div>
<!-- view model -->

<!-- Modal -->
<div class="modal" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true"><i class="text-danger fa fa-times"></i></button>
        <h4 class="modal-title" id="myModalLabel"><i class="text-muted fa fa-shopping-cart"></i> <strong>02051</strong> - Nome do Produto </h4>
      </div>
      <div class="modal-body">

        <table class="pull-left col-md-8 ">
          <tbody>
            <tr>
              <td class="h6"><strong>Código</strong></td>
              <td> </td>
              <td class="h5">02051</td>
            </tr>

            <tr>
              <td class="h6"><strong>Descrição</strong></td>
              <td> </td>
              <td class="h5">descrição do produto</td>
            </tr>

            <tr>
              <td class="h6"><strong>Marca/Fornecedor</strong></td>
              <td> </td>
              <td class="h5">Marca do produto</td>
            </tr>

            <tr>
              <td class="h6"><strong>Número Original</strong></td>
              <td> </td>
              <td class="h5">0230316</td>
            </tr>

            <tr>
              <td class="h6"><strong>Código N.C.M</strong></td>
              <td> </td>
              <td class="h5">032165</td>
            </tr>

            <tr>
              <td class="h6"><strong>Código de Barras</strong></td>
              <td> </td>
              <td class="h5">0321649843</td>
            </tr>

            <tr>
              <td class="h6"><strong>Unid. por Embalagem</strong></td>
              <td> </td>
              <td class="h5">50</td>
            </tr>

            <tr>
              <td class="h6"><strong>Quantidade Mínima</strong></td>
              <td> </td>
              <td class="h5">50</td>
            </tr>

            <tr>
              <td class="h6"><strong>Preço Atacado</strong></td>
              <td> </td>
              <td class="h5">R$ 35,00</td>
            </tr>

            <tr>
              <td class="btn-mais-info text-primary">
                <i class="open_info fa fa-plus-square-o"></i>
                <i class="open_info hide fa fa-minus-square-o"></i> informações
              </td>
              <td> </td>
              <td class="h5"></td>
            </tr>

          </tbody>
        </table>


        <div class="col-md-4">
          <img src="http://lorempixel.com/150/150/technics/" alt="teste" class="img-thumbnail">
        </div>

        <div class="clearfix"></div>
        <p class="open_info hide">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
      </div>

      <div class="modal-footer">

        <div class="text-right pull-right col-md-3">
          Varejo: <br />
          <span class="h3 text-muted"><strong> R$50,00 </strong></span></span>
        </div>

        <div class="text-right pull-right col-md-3">
          Atacado: <br />
          <span class="h3 text-muted"><strong>R$35,00</strong></span>
        </div>

      </div>
    </div>
  </div>
</div>
<!-- fim Modal-->

<script>
  window.addEventListener('load', function() {
    loadProduct();
  })
</script>
<?php require_once("footer.php"); ?>