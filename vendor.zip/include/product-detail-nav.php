   
    <section class="innerproductdetails_tabs container-fluid">
        <div class="container">
            <div class="row">
                <header id="secondary-nav" class="secondary-nav shadow-sm position-sticky">
<div class="container">
<nav class="vam nav scroll dragger scroller">
    
    <li class="nav-item"><a href="#overview" class="nav-link">Overview</a></li>
    <li class="nav-item"><a href="#price" class="nav-link">Price</a></li>
    <li class="nav-item"><a href="#spec" class="nav-link">Specs</a></li>
    <li class="nav-item"><a href="#gallery" class="nav-link">Images</a></li>
    <li class="nav-item"><a href="#about" class="nav-link">About Product</a></li>
    
    <li class="nav-item"><a href="#review" class="nav-link">Product Review</a></li>
    <li class="nav-item"><a href="#feedback" class="nav-link">Your Feedback</a></li>
    <li class="nav-item"><a href="#faq" class="nav-link">FAQ's</a></li>
    <li class="nav-item"><a href="#similarev" class="nav-link">Similar EV</a></li>
</nav>
  
</div>
</header>
            </div>
        </div>
    </section>