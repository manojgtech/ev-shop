
        <!-- Start Footer Area -->
        <footer class="footer-area creativefootersection">
            <div class="container">
                <div class="row">
                    
                    <div class="col-md-12 footerlogo">
                        <a href="index.php">
                            <img src="assets/img/EVFY-footer-logo.png" alt="EVFY" title="">
                        </a>
                    </div>
                    
                    <div class="col-lg-3 col-md-6 col-sm-6 commonfootercolumn">
                        <div class="single-footer-widget mb-30">
                            <h3>Evfy.in</h3>

                             <ul class="support-link">
                                <li><a href="#">Personal Mobility</a></li>
                                <li><a href="e-cycle.php">E-Cycles</a></li>
                                <li><a href="kinetic-zing.php">Kinetic Zing</a></li>
                                <li><a href="kinetic-zoom.php">Kinetic Zoom</a></li>
                                <li><a href="login.php">Login</a></li>
                                 <li><a href="register.php">Register</a></li>
                            </ul>

                            
                        </div>
                    </div>

                    <div class="col-lg-2 col-md-6 col-sm-6 commonfootercolumn">
                        <div class="single-footer-widget mb-30">
                            <h3>Quick Links</h3>

                            <ul class="support-link">
                                 <li><a href="about.php">About EVFY</a></li>
                                <li><a href="why-choose-electric.php">Why Choose Electric?</a></li>
                                <li><a href="lets-connect.php">Lets Connect</a></li>
                                <li><a href="#">EV Warranty</a></li>
                                <li><a href="faq.php">FAQ's</a></li>
                                <li><a href="my-account.php">My Account</a></li>
                                
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6 commonfootercolumn">
                        <div class="single-footer-widget mb-30">
                            <h3>Contact Us</h3>

                            <ul class="useful-link">
                                <li><a href="#">EVFY Blog</a></li>
                                <li><a href="mailto:info@evfy.in">Work With EVFY</a></li>
                                <li><a href="mailto:info@evfy.in">Contact Us</a></li>
                                <li><a href="dealer.php">Are you a dealer?</a></li>
                                <li><a href="#">Terms & Condition</a></li>
                                <li><a href="#">Privacy Policy</a></li>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-6 col-sm-6 commonfootercolumn">
                        <div class="single-footer-widget mb-30">
                            <h3>Get Connected</h3>

                            <div class="newsletter-box">
<!--                                <p>To get the latest news and latest updates from us.</p>-->

                                <form class="newsletter-form" data-toggle="validator">
                                    <label>Your e-mail address:</label>
                                    <input type="email" class="input-newsletter" placeholder="Get latest news & updates from EVFY.

" name="EMAIL" required autocomplete="off">
                                    <button type="submit">Subscribe</button>
                                    <div id="validator-newsletter" class="form-result"></div>
                                </form>
                            </div>
                            <ul class="social-link">
                                <li><a href="https://www.facebook.com/EVfy-100126905756293" class="d-block" target="_blank"><i class='fa fa-facebook'></i></a></li>
                                <li><a href="https://twitter.com/evfyin" class="d-block" target="_blank"><i class='fa fa-twitter'></i></a></li>
                                <li><a href="https://www.instagram.com/evfy.in/" class="d-block" target="_blank"><i class='fa fa-instagram'></i></a></li>
                                <li><a href="https://api.whatsapp.com/send?phone=918285932633&text=&source=&data=&app_absent=" class="d-block" target="_blank"><i class='fa fa-whatsapp'></i></a></li>
                                
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="footer-bottom-area">
                <div class="container">
<!--
                    <div class="logo">
                        <a href="index-4.html" class="d-inline-block"><img src="assets/img/EVFY-logo.png" alt="image"></a>
                    </div>
-->
                    <p>Copyright <i class='fa fa-copyright'></i> 2021 <a href="#" target="_blank">evfy</a> | All rights reserved.</p>
                </div>
            </div>
        </footer>
        <!-- End Footer Area -->
        
        <div class="go-top"><i class='fa fa-flash'></i></div>