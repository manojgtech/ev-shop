<!-- Start Main Banner -->
        <section class="car-slides owl-carousel owl-theme evfyhomeslidersection quickcarselectionsection">
            <div class="main-banner item-bg1">
                <div class="d-table">
                    <div class="d-table-cell">
                        <div class="container">
                            <div class="main-banner-content text-center">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
           

            <div class="main-banner item-bg2">
                <div class="d-table">
                    <div class="d-table-cell">
                        <div class="container">
                                <div class="main-banner-content text-center">
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            

            <div class="main-banner item-bg3">
                <div class="d-table">
                    <div class="d-table-cell">
                        <div class="container">
                            <div class="main-banner-content text-center">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
      
          
        </section>
        <!-- End Main Banner -->