<?php require_once("header.php"); ?>
 <?php 
  $results1 = DB::query("SELECT * FROM products WHERE status=1");


?>
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Products</h6>
                            <i class="fa fa-plus float-right"></i>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <?php if(!empty($results1)){ ?>
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                             <th><input type="checkbox" name="allcats" id="allids" onclick="checkAll(this.id);" /></th>
                                            <th>Product Title</th>
                                            <th>Categories</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                            <th>Created At</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th><input type="checkbox" name="allcats" id="allids1" onclick="checkAll(this.id);" /></th>
                                            <th>Product Title</th>
                                            <th>Categories</th>
                                            <th>Price</th>
                                            <th>Status</th>
                                            <th>Created At</th>
                                            <th>Actions</th>
                                        </tr>
                                    </tfoot>
                                    <tbody> 
                                        <?php foreach($results1 as $row){ ?>
                                        <tr id="row_<?php echo $row['id']; ?>" data-id="<?php echo $row['id']; ?>">
                                            <td><input type="checkbox" name="allcats" class="pids"  id="check_<?php echo $row['id']; ?>"   data-id="<?php echo $row['id']; ?>" onclick="chechThisc(<?php echo $row['id']; ?>,this.id);" /></td>
                                            <td><?php echo $row['title']; ?></td>
                                            <td><?php echo $row['category_id']; ?></td>
                                            <td><?php echo $row['ex_showroom_price']; ?>Rs</td>
                                            <td><?php echo ($row['status']==1) ? 'Active':'Disabled'; ?></td>
                                            <td><?php echo $row['created_at']; ?></td>
                                            <td><i class="fa fa-edit" data-id="<?php echo $row['id']; ?>" onclick="showEditForm(<?php echo $row['id']; ?>);"></i>&nbsp;|&nbsp;<i class="fa fa-trash" data-id="<?php echo $row['id']; ?>" onclick="showDelAlert(<?php echo $row['id']; ?>);"></i></td>
                                        </tr>
                                        <?php }?>
                                    </tbody>
                                </table>
                                <?php }else{ ?>
                                 <div class="alert alert-warning">No products found!</div>
                                <?php } ?>    
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- End of Main Content -->
<div class="modal fade" tabindex="-1" role="dialog" id="editcatspopup">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Edit Category</h4>
        <button type="button" class="close" style="float:right;" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form id="cat-form">
                                
       </form>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div class="modal fade" tabindex="-1" role="dialog" id="deletecatspopup">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Delete Category</h4>
        <button type="button" class="close" style="float:right;" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <p>Do you want to delete it?</p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary"  id="delpopup_btn" data-id="" onclick="delcat();">Save changes</button>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

            <!-- Footer -->
            <?php require_once("footer.php"); ?>
           