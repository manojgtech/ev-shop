<?php 
require_once('/vendor/config.php');
require_once('/vendor/dbconnect.php');
require_once('/vendor/constant.php');



?>