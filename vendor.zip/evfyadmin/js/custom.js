var ids=[];
var baseurl="http://localhost:8081/evfy/";
function chechThisc(id,pid){
    console.log(id,pid);
    if($("#"+pid).is(":checked")){
        if(!ids.includes(id)){
        ids.push(id);
        }
    }else{
        if(ids.includes(id)){
            var i=ids.indexOf(id);
             if (i > -1) {
                ids.splice(i, 1); 
            }
        }
    }
    
    
}

function checkAll(id){
    if($("#"+id).is(":checked")){
        $("thead input").attr("checked","checked");
        $("tfoot input").attr("checked","checked");
        var trs=$("tbody tr");
       
        if(ids.length<trs.length){
            trs.each(function(index){
                 console.log(this);
            ids.push($(this).attr("data-id"));
            $(this).find(".pids").attr("checked","checked");
            });
        }
   }else{
       $("thead input").removeAttr("checked");
        $("tfoot input").removeAttr("checked");
        $(".pids").removeAttr("checked");
       ids=[];
   }
    
}

function showEditForm(id){
    $("#cat-form").html('');
     $.ajax({
     type: "POST",
     url: baseurl+'vendor/catModel.php',
     data: {id:id,func:'editC'},
     success: function(response){
         console.log(response);
         $("#cat-form").html(response);
         $("#editcatspopup").modal();
     }
});
    
}
function showDelAlert(id){
    $("#delpopup_btn").data("id",id);
    $("#deletecatspopup").modal();
}

$(document).ready(function(){
    loadCategory();
});

function loadCategory(){
                    $.ajax({
                type: "POST",
                url: baseurl+'vendor/catModel.php',
                data: {func:'viewC'},
                success: function(response){
                    console.log(response);
                    $("#catdiv").html(response);
                     $('#catdataTable').DataTable();
                }
            });
    }

